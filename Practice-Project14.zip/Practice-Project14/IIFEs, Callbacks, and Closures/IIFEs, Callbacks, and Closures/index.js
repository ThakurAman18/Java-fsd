// IIFE (Immediately Invoked Function Expression)
(function () {
    var x = 10;
  
    // Callback function
    function callback() {
      console.log("Callback executed!");
      console.log("x =", x); // Accessing variable x from the closure
    }
  
    // Closure
    function outerFunction(callback) {
      var y = 5;
  
      function innerFunction() {
        console.log("Inner function executed!");
        console.log("y =", y); // Accessing variable y from the closure
        callback(); // Calling the callback function
      }
  
      return innerFunction;
    }
  
    var closureFunction = outerFunction(callback); // Closure function returned
  
    closureFunction(); // Executing the closure function
  })();
  
// Creating a Map
let myMap = new Map();

// Adding key-value pairs to the Map
myMap.set("name", "John");
myMap.set("age", 30);
myMap.set("city", "New York");

// Accessing values from the Map
console.log(myMap.get("name")); // 
console.log(myMap.get("age")); // 
console.log(myMap.get("city")); // 

// Checking if a key exists in the Map
console.log(myMap.has("name")); // \
console.log(myMap.has("address")); // 

// Deleting a key-value pair from the Map
myMap.delete("age");

// Iterating over the Map
for (let [key, value] of myMap) {
  console.log(key, value);
}

// Creating a class
class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  sayHello() {
    console.log(`Hello, my name is ${this.name} and I'm ${this.age} years old.`);
  }
}

// Creating an instance of the Person class
let person = new Person("Alice", 25);

// Accessing properties and calling methods
console.log(person.name); // 
console.log(person.age); // 
person.sayHello(); // 
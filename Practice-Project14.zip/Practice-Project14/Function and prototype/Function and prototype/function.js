// Function declaration
function greet(name) {
    console.log(`Hello, ${name}!`);
  }
  
  // Function expression
  const add = function(a, b) {
    return a + b;
  };
  
  // Function invocation
  greet("John"); // Output: Hello, John!
  console.log(add(3, 5)); // Output: 8
  
  // Function prototype
  function Person(name, age) {
    this.name = name;
    this.age = age;
  }
  
  Person.prototype.introduce = function() {
    console.log(`Hi, my name is ${this.name} and I'm ${this.age} years old.`);
  };
  
  // Object instantiation
  const john = new Person("John", 25);
  const jane = new Person("Jane", 30);
  
  john.introduce(); // 
  jane.introduce(); // 
  
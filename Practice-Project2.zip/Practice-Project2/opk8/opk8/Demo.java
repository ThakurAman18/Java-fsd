package opk8;



public class Demo {
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	        
			
			Student st1 = new Student(15);
			
			st1.studentId = 123;
			st1.studentCity = "Ballia";
			st1.studentName = "Aman thakur";
			
			
			st1.fullDetails();
			
			
			Student s2 = new Student(123,"balliajila","Thakursahab");
			s2.fullDetails();
		}

	}


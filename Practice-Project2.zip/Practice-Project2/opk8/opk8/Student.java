package opk8;

public class Student {
	
	    int studentId;
	    String studentName;
	    String studentCity;
	    
	    //methods
	    
	    public void  study() {
	    	System.out.println(studentName + "is studying");
	    }
	    //concept of constructer
	    // non-paramaterized constructer
	    public Student() {
	    	System.out.println("constructer is running");
	    }
	    // Parametrized constructer
	    
	    public Student(int n) {
	    	 System.out.println("pramaterized constructer");
	    }
	    
	    public Student(int n ,String i, String j) {
	    	 studentId = n;
	         studentName = i;
	        
	         studentCity = j;
	    }
	    
	    public void fullDetails() {
	    	
	    	System.out.println(studentId + "my id is");
	    	System.out.println(studentCity + "my city is");
	    	System.out.println(studentName + "is studying");
	    }
		
	}



package opk5;

public class Exceptions {

	  
	  public static void methodThatThrows() throws Exception {
	    throw new Exception("Exception thrown from methodThatThrows");
	  }

	  
	  public static void methodThatCatches() {
	    try {
	      methodThatThrows();
	    } catch (Exception e) {
	      System.out.println("Caught exception: " + e.getMessage());
	    } finally {
	      System.out.println("In finally block");
	    }
	  }

	  
	  public static class CustomException extends Exception {
	    public CustomException(String message) {
	      super(message);
	    }
	  }

	  
	  public static void methodThatThrowsCustom() throws CustomException {
	    throw new CustomException("Custom exception thrown from methodThatThrowsCustom");
	  }

	  public static void main(String[] args) {
	    
	    try {
	      methodThatThrows();
	    } catch (Exception e) {
	      System.out.println("Caught exception: " + e.getMessage());
	    }

	    
	    try {
	      throw new Exception("Manually thrown exception");
	    } catch (Exception e) {
	      System.out.println("Caught exception: " + e.getMessage());
	    }

	    
	    methodThatCatches();

	    
	    try {
	      methodThatThrowsCustom();
	    } catch (CustomException e) {
	      System.out.println("Caught custom exception: " + e.getMessage());
	    }
	  }
	}


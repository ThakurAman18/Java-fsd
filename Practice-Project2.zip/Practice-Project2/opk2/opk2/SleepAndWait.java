package opk2;

public class SleepAndWait{

    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object();

        // Sleep for 1 second
        System.out.println("Sleeping for 3 second...");
        Thread.sleep(3000);
        System.out.println("Done sleeping.");

        // Wait for a signal
        synchronized (lock) {
            System.out.println("Waiting for signal...");
            lock.wait();
            System.out.println("Got signal!");
        }

     // Send a signal
        synchronized (lock) {
            lock.notify();
        }
    }

}


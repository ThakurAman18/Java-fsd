package Assignment7;

public class InnerClassExample {
    
    private int outerVariable = 10;
    
    // Inner class
    public class InnerClass {
        
        public void printOuterVariable() {
            System.out.println("Outer variable value: " + outerVariable);
        }
        
    }
    
    public static void main(String[] args) {
        InnerClassExample outerObj = new InnerClassExample();
        InnerClassExample.InnerClass innerObj = outerObj.new InnerClass();
        innerObj.printOuterVariable();
    }
    
}


package assignment4;



	public class ConstructorExample {
	    private int value;
	    
	    // Default constructor
	    public ConstructorExample() {
	        this.value = 0;
	    }
	    
	    // Parameterized constructor
	    public ConstructorExample(int value) {
	        this.value = value;
	    }
	    
	    // Copy constructor
	    public ConstructorExample(ConstructorExample other) {
	        this.value = other.value;
	    }
	    
	    // Private constructor
	    private ConstructorExample(String message) {
	        System.out.println(message);
	    }
	    
	    public static void main(String[] args) {
	        // Default constructor
	        ConstructorExample ce1 = new ConstructorExample();
	        System.out.println("ce1 value: " + ce1.value);
	        
	        // Parameterized constructor
	        ConstructorExample ce2 = new ConstructorExample(5);
	        System.out.println("ce2 value: " + ce2.value);
	        
	        // Copy constructor
	        ConstructorExample ce3 = new ConstructorExample(ce2);
	        System.out.println("ce3 value: " + ce3.value);
	        
	        
	        
	    }
	}




package io.com;

public class pracas1 {
    
    public static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; 
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int[] array = { 4, 2, 9, 7, 1, 5, 6, 3, 8 };
        int target = 5;
        
        int index = linearSearch(array, target);
        if (index != -1) {
            System.out.println("Target element found at index " + index);
        } else {
            System.out.println("Target element not found in the array.");
        }
    }
}

package Assignment6;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {
    
    public void testHashMapPutAndGet() {
        Map<String, Integer> map = new HashMap<>();
        
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        assert(map.get("one") == 1);
        assert(map.get("two") == 2);
        assert(map.get("three") == 3);
    }
    
    public void testHashMapContainsKey() {
        Map<String, Integer> map = new HashMap<>();
        
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        assert(map.containsKey("one"));
        assert(map.containsKey("two"));
        assert(map.containsKey("three"));
        assert(!map.containsKey("four"));
    }
    
    public void testHashMapSize() {
        Map<String, Integer> map = new HashMap<>();
        
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        assert(map.size() == 3);
        
        map.put("four", 4);
        
        assert(map.size() == 4);
    }
    
    public static void main(String[] args) {
        HashMapTest test = new HashMapTest();
        
        test.testHashMapPutAndGet();
        test.testHashMapContainsKey();
        test.testHashMapSize();
        
        System.out.println("All tests passed!");
    }
}


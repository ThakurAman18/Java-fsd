package Assignment5;

import java.util.Collection;

public class CollectionVerifier {

    public static boolean verify(Collection<?> collection) {
        int initialSize = collection.size();

        // Add an element to the collection
        Object element = new Object();
        collection.add(element);
        if (collection.size() != initialSize + 1) {
            System.out.println("Error: Failed to add element to collection.");
            return false;
        }

        // Remove the element from the collection
        if (!collection.remove(element)) {
            System.out.println("Error: Failed to remove element from collection.");
            return false;
        }
        if (collection.size() != initialSize) {
            System.out.println("Error: Failed to remove element from collection.");
            return false;
        }

        // Clear the collection
        collection.clear();
        if (collection.size() != 0) {
            System.out.println("Error: Failed to clear collection.");
            return false;
        }

        // Add multiple elements to the collection
        collection.add(new Object());
        collection.add(new Object());
        collection.add(new Object());
        if (collection.size() != 3) {
            System.out.println("Error: Failed to add multiple elements to collection.");
            return false;
        }

        // Check if the collection contains an element
        if (!collection.contains(element)) {
            System.out.println("Error: Failed to find element in collection.");
            return false;
        }

        return true;
    }

    public static void main(String[] args) {
        // Test an ArrayList
        Collection<Object> arrayList = new java.util.ArrayList<>();
        if (verify(arrayList)) {
            System.out.println("ArrayList passed verification.");
        }

        // Test a HashSet
        Collection<Object> hashSet = new java.util.HashSet<>();
        if (verify(hashSet)) {
            System.out.println("HashSet passed verification.");
        }
    }
}


package opk8;

//Encapsulation
class Car {
 private String make;
 private String model;
 private int year;
 
 public Car(String make, String model, int year) {
     this.make = make;
     this.model = model;
     this.year = year;
 }
 
 public String getMake() {
     return make;
 }
 
 public void setMake(String make) {
     this.make = make;
 }
 
 public String getModel() {
     return model;
 }
 
 public void setModel(String model) {
     this.model = model;
 }
 
 public int getYear() {
     return year;
 }
 
 public void setYear(int year) {
     this.year = year;
 }
}

//Inheritance
class ElectricCar extends Car {
 private int batteryLife;
 
 public ElectricCar(String make, String model, int year, int batteryLife) {
     super(make, model, year);
     this.batteryLife = batteryLife;
 }
 
 public int getBatteryLife() {
     return batteryLife;
 }
 
 public void setBatteryLife(int batteryLife) {
     this.batteryLife = batteryLife;
 }
}

//Polymorphism
class Animal {
 public void makeSound() {
     System.out.println("The animal makes a sound");
 }
}

class Dog extends Animal {
 public void makeSound() {
     System.out.println("The dog barks");
 }
}

class Cat extends Animal {
 public void makeSound() {
     System.out.println("The cat meows");
 }
}

class oopsPiilar {
 public static void main(String[] args) {
     // Encapsulation
     Car car = new Car("Toyota", "Corolla", 2021);
     System.out.println(car.getMake() + " " + car.getModel() + " " + car.getYear());
     
     // Inheritance
     ElectricCar electricCar = new ElectricCar("Tesla", "Model S", 2022, 500);
     System.out.println(electricCar.getMake() + " " + electricCar.getModel() + " " + electricCar.getYear() + " " + electricCar.getBatteryLife() + " miles");
     
     // Polymorphism
     Animal animal = new Animal();
     animal.makeSound();
     
     Dog dog = new Dog();
     dog.makeSound();
     
     Cat cat = new Cat();
     cat.makeSound();
 }
}


package iot.com;

import java.util.Scanner;

public class SessionLoginLogoutDemo {
    private static boolean isLoggedIn = false;
    private static String username;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Welcome to the Session Login/Logout Demo");
            System.out.println("----------------------------------------");
            System.out.println("1. Login");
            System.out.println("2. Logout");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    logout();
                    break;
                case 3:
                    System.out.println("Exiting the program. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void login(Scanner scanner) {
        if (isLoggedIn) {
            System.out.println("You are already logged in. Please logout first.");
            return;
        }

        System.out.print("Enter your username: ");
        String inputUsername = scanner.nextLine();

        // Simulating authentication
        if (authenticateUser(inputUsername)) {
            isLoggedIn = true;
            username = inputUsername;
            System.out.println("Login successful. Welcome, " + username + "!");
        } else {
            System.out.println("Invalid username. Login failed.");
        }
    }

    private static boolean authenticateUser(String inputUsername) {
        // Add your authentication logic here
        // For simplicity, we're accepting any non-empty username as valid
        return !inputUsername.isEmpty();
    }

    private static void logout() {
        if (!isLoggedIn) {
            System.out.println("You are not logged in. Please login first.");
            return;
        }

        System.out.println("Logout successful. Goodbye, " + username + "!");
        isLoggedIn = false;
        username = null;
    }
}


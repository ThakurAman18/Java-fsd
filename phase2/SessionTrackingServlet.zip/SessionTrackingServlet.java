package iot.com;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionTrackingServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the current session or create a new one if it doesn't exist
        HttpSession session = request.getSession(true);
        
        // Get the current session ID
        String sessionId = session.getId();
        
        // Set a cookie with the session ID
        Cookie sessionCookie = new Cookie("sessionId", sessionId);
        response.addCookie(sessionCookie);
        
        // Set the content type and get the response writer
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Write the session ID to the response
        out.println("<html><body>");
        out.println("Session ID: " + sessionId);
        out.println("</body></html>");
        
        // Invalidate the session
        session.invalidate();
    }
}

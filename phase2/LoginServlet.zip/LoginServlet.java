package iot.com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        if (username.equals("admin") && password.equals("admin123")) {
            // Create a session identifier
            String sessionId = generateSessionId();
            
            // Set the session identifier in a cookie
            Cookie sessionCookie = new Cookie("sessionId", sessionId);
            response.addCookie(sessionCookie);
            
            // Redirect to the home page with the session identifier
            response.sendRedirect("HomePageServlet;jsessionid=" + sessionId);
        } else {
            response.sendRedirect("login.html");
        }
    }
    
    private String generateSessionId() {
        // Generate a unique session identifier using any suitable logic
        // For simplicity, a random UUID is used here
        return java.util.UUID.randomUUID().toString();
    }
}

package Assignment9;

public class ArrayVerification {
    public static void main(String[] args) {
        // Declare and initialize an array
        int[] myArray = {1, 2, 3, 4, 5};
        
        // Print the contents of the array
        System.out.println("Original Array:");
        for (int i = 0; i < myArray.length; i++) {
            System.out.print(myArray[i] + " ");
        }
        System.out.println();
        
        // Change the value at index 2
        myArray[2] = 10;
        
        // Print the contents of the modified array
        System.out.println("Modified Array:");
        for (int i = 0; i < myArray.length; i++) {
            System.out.print(myArray[i] + " ");
        }
        System.out.println();
        
        // Get the length of the array
        int length = myArray.length;
        System.out.println("Length of the array is: " + length);
        
        // Find the sum of all elements in the array
        int sum = 0;
        for (int i = 0; i < myArray.length; i++) {
            sum += myArray[i];
        }
        System.out.println("Sum of all elements in the array is: " + sum);
        
        // Find the maximum value in the array
        int max = myArray[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] > max) {
                max = myArray[i];
            }
        }
        System.out.println("Maximum value in the array is: " + max);
    }
}


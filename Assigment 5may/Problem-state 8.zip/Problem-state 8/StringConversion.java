package Assignment8;

public class StringConversion {
	  public static void main(String[] args) {
	    String str = "Hello, world!";
	    StringBuffer sb = new StringBuffer(str);
	    StringBuilder sbuilder = new StringBuilder(str);

	    // Displaying the original string and the converted StringBuffer and StringBuilder objects
	    System.out.println("Original string: " + str);
	    System.out.println("StringBuffer object: " + sb);
	    System.out.println("StringBuilder object: " + sbuilder);
	  }
	}


package typeCasting;

public class TypeCasting {

	public static void main(String[] args) {
		
		    
		        // Implicit type casting
		        int x = 10;
		        double y = x;
		        System.out.println("x = " + x);
		        System.out.println("y = " + y);
		        
		        // Explicit type casting
		        double a = 10.5;
		        int b = (int) a;
		        System.out.println("a = " + a);
		        System.out.println("b = " + b);
		    }
		}






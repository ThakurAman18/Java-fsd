package opk;

public class MyRunnable implements Runnable {
    public void run() {
        System.out.println("MyRunnable running");
    }

    public static void main(String[] args) {
        MyRunnable myRunnable = new MyRunnable();
        Thread t = new Thread(myRunnable);
        t.start();
    }
}
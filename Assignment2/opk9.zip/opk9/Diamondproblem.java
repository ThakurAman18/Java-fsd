package opk9;

interface Animal {
    void eat();
}

interface Bird extends Animal {
    void fly();
}

interface Mammal extends Animal {
    void run();
}

class Bat implements Bird, Mammal {
    public void eat() {
        System.out.println("Bat is eating.");
    }

    public void fly() {
        System.out.println("Bat is flying.");
    }

    public void run() {
        System.out.println("Bat is running.");
    }
}

public class Diamondproblem {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.eat();
        bat.fly();
        bat.run();
    }
}




package Assignment10;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegexVerifier {
    public static void main(String[] args) {
        String regexPattern = args[0];
        String testString = args[1];
        
        Pattern pattern = Pattern.compile(regexPattern);
        Matcher matcher = pattern.matcher(testString);
        
        if (matcher.matches()) {
            System.out.println("The regular expression matches");
        } else {
            System.out.println("The regular expression does not match");
        }
    }
}


package Methodcalling;

public class MethodCalling {

 // A simple method that adds two numbers
		    public static int addNumbers(int a, int b) {
		        return a + b;
		    }
		    
		    // Main method to test the addNumbers method
		    public static void main(String[] args) {
		        
		        // Test the addNumbers method with different arguments
		        int result1 = addNumbers(2, 3); 
		        int result2 = addNumbers(0, 0); 
		        int result3 = addNumbers(-5, 10); 
		        
		        // Verify the results
		        System.out.println("Result 1: " + (result1 == 5));
		        System.out.println("Result 2: " + (result2 == 0));
		        System.out.println("Result 3: " + (result3 == 5));
		    }
		


	}



package AccessModifier;




	public class MyClass {
	    public int publicVar;       // Public variable
	    private int privateVar;     // Private variable
	    protected int protectedVar; // Protected variable

	    // Constructor
	    public MyClass(int publicVar, int privateVar, int protectedVar) {
	        this.publicVar = publicVar;
	        this.privateVar = privateVar;
	        this.protectedVar = protectedVar;
	    }

	    // Getter and setter for private variable
	    public int getPrivateVar() {
	        return privateVar;
	    }
	    public void setPrivateVar(int privateVar) {
	        this.privateVar = privateVar;
	    }

	    // Method with default access modifier
	    void defaultMethod() {
	        System.out.println("This is a default method.");
	    }

	    // Public method
	    public void publicMethod() {
	        System.out.println("This is a public method.");
	    }

	    // Protected method
	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }
	


	public static void main(String[] args) {
	    MyClass myObject = new MyClass(1, 2, 3);

	    // Access public variable
	    myObject.publicVar = 10;

	    // Access private variable using getter and setter methods
	    myObject.setPrivateVar(20);
	    System.out.println("Private variable value: " + myObject.getPrivateVar());

	    // Access protected variable (only allowed within same package or subclass)
	    myObject.protectedVar = 30;

	    // Call methods with different access modifiers
	    myObject.defaultMethod();
	    myObject.publicMethod();
	    myObject.protectedMethod();
	}


	}

package io.com;

public class praccas3 {

    public static int exponentialSearch(int[] arr, int key) {
        if (arr[0] == key) {
            return 0; 
        }
        
        int n = arr.length;
        int i = 1;
        while (i < n && arr[i] <= key) {
            i *= 2; 
        }
        
        return binarySearch(arr, i / 2, Math.min(i, n - 1), key);
    }

    private static int binarySearch(int[] arr, int low, int high, int key) {
        if (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == key) {
                return mid; 
            } else if (arr[mid] < key) {
                return binarySearch(arr, mid + 1, high, key); 
            } else {
                return binarySearch(arr, low, mid - 1, key); 
            }
        }
        
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
        int key = 23;
        int index = exponentialSearch(arr, key);
        
        if (index != -1) {
            System.out.println("Key found at index " + index);
        } else {
            System.out.println("Key not found");
        }
    }
}
